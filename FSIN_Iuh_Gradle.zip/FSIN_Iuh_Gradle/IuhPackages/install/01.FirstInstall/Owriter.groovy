import groovy.util.logging.Log4j
import ru.datateh.jbr.iuh.AbstractExecute
import ru.datateh.jbr.iuh.utils.FileUtils

/**
 * @author etarakanov
 * Date: 27.03.2015
 * Time: 12:51
 */
@Log4j
public class Owriter extends AbstractExecute
{
    private static String IUH_LOCAL_SHARED_FOLDER = "br4j.dbmi.owriter.local.shared.folder";
    private static String IUH_SERVICE_SHARED_FOLDER = "br4j.dbmi.owriter.service.shared.folder";
    private static String IUH_SERVICE_BASE_URL = "br4j.dbmi.owriter.service.base.url";

    private static String LOCAL_SHARED_FOLDER = "owriter.local.shared.folder";
    private static String SERVICE_SHARED_FOLDER = "owriter.service.shared.folder";
    private static String SERVICE_BASE_URL = "owriter.service.base.url";

    private Map<String, String> properties;

    public void install() {
        log.info "Owriter is running... "

        File fileProperties = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'owriter' + File.separator + 'service.properties');

        File exampleProperties = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'owriter' + File.separator + 'service.properties.example');

        if (!FileUtils.checkFileExist(fileProperties, false) && FileUtils.checkFileExist(exampleProperties, true))
        {
            log.info "Property file: " + fileProperties + " missing. File will be created from copy: " + exampleProperties;
            FileUtils.copyFile(exampleProperties, fileProperties);
            if (!checkPropertiesValues(fileProperties)) {
                updateRequiredProperty(fileProperties);
            }
            FileUtils.changeFilePermission(fileProperties, FileUtils.Permission.WRITE, false);
        }
    }

    private Map<String, String> collectProperties ()
    {
        if (properties == null)
        {
            properties = new HashMap<String, String>();
            properties.put(IUH_LOCAL_SHARED_FOLDER,
                    getPropertyValue(IUH_LOCAL_SHARED_FOLDER, null));
            properties.put(IUH_SERVICE_SHARED_FOLDER,
                    getPropertyValue(IUH_SERVICE_SHARED_FOLDER, null));
            properties.put(IUH_SERVICE_BASE_URL,
                    getPropertyValue(IUH_SERVICE_BASE_URL, null));
        }
        return properties
    }

    private boolean checkPropertiesValues (File propertiesFile)
    {
        if (PropertiesUtils.checkPropertyEquals(propertiesFile, collectProperties()).isEmpty()) {
            return true;
        }
        return false;
    }

    private void updateRequiredProperty(File propertiesFile)
    {
        log.info("Updating file: " + propertiesFile);
        List<String> fileLines = FileUtils.readLines(propertiesFile);
        log.info("Updating property: " + LOCAL_SHARED_FOLDER);
        PropertiesUtils.updateProperty(fileLines, LOCAL_SHARED_FOLDER, getTransformedPath(collectProperties().get(IUH_LOCAL_SHARED_FOLDER)),
                "Edited by Owriter script at: " + new Date());
        log.info("Updating property: " + SERVICE_SHARED_FOLDER);
        PropertiesUtils.updateProperty(fileLines, SERVICE_SHARED_FOLDER, getTransformedPath(collectProperties().get(IUH_SERVICE_SHARED_FOLDER)),
                "Edited by Owriter script at: " + new Date());
        log.info("Updating property: " + SERVICE_BASE_URL);
        PropertiesUtils.updateProperty(fileLines, SERVICE_BASE_URL, collectProperties().get(IUH_SERVICE_BASE_URL),
                "Edited by Owriter script at: " + new Date());
        FileUtils.storeLines(propertiesFile, fileLines);
        log.info("Updating file: " + propertiesFile + " finished");
    }

    private String getTransformedPath (String path)
    {
        File checkedPath = new File(path);
        if (checkedPath.isAbsolute()){
            return path;
        } else {
            return map.get('br4j.jboss.configuration.path') + File.separator + path;
        }
    }

    public static void main(String[] args) {
        new Owriter().start();
    }

}
