package ru.datateh.jbr.iuh
import groovy.sql.Sql
import groovy.util.logging.Log4j
import ru.datateh.jbr.iuh.utils.FileUtils
import ru.datateh.jbr.iuh.utils.PropertiesUtils

@Log4j
class ScriptExecutor {
	
	private Map<String, String> map
	private boolean interactive;
	//private Set<String> userValues
	
	private Scanner scan = new Scanner(System.in)
	
	public static final String DBMI_DB_URL = 'br4j.dbmi.db.url'
	public static final String DBMI_DB_DRIVER = 'br4j.dbmi.db.driver'
	
	final public void setMap(Map<String, String> map) {
		this.map = map
		this.interactive = map.get('iuh.mode.interactive') ? Boolean.valueOf(map.get('iuh.mode.interactive')) : false
	}
	
	/*final public Set<String> getUserValues() {
		return userValues
	}*/
	
	final protected void execSql(String sql) {
	
		def conn = Sql.newInstance(map[DBMI_DB_URL], map['dbLogin'], null, map[DBMI_DB_DRIVER])
		conn.execute(sql)
	}
	
	final protected void execSqlFromFile(String file) {
		
		def scriptDir = map.get('scriptDir')
		if(scriptDir == null) {
			throw new IllegalStateException(scriptDir + ' is null, file ' + file + ' cannot be executed')
		}
		File script = new File(scriptDir + File.separator + 'data' + File.separator + file)
		BufferedReader br = new BufferedReader(new FileReader(script))
		String line;
		StringBuilder sb = new StringBuilder()
		while((line = br.readLine()) != null) {
			sb.append(line)
		}
		
		execSql(sb.toString())
	}
	
	final protected void putValue(String parameterName, String parameterValue) {
        String answersFileName = map.get("iuh.answers.file");
        File answerFile = new File(answersFileName);
        log.debug ("Write parameter " + parameterName + " with value " + parameterValue + " in file " + answersFileName);
        boolean isInteractive = Boolean.parseBoolean(map.get("iuh.mode.interactive"));
        if (isInteractive && (answersFileName != null && !answersFileName.isEmpty()))
        {
            if (FileUtils.checkFileExist(answerFile, false)) {
                log.debug("Write parameter : " + parameterName + " with value: " + parameterValue + " in answer file: " + answersFileName);
                PropertiesUtils.addPropertyAndSave(answerFile, map.get("iuh.answers.prefix") + "." + parameterName, parameterValue, null);
                log.debug ("Writing parameter success")
            }
        }
	}
	
	final protected String getValue(String name) {
        File file;
		String answerFileName = map.get('iuh.answers.file');
        if (answerFileName != null && !answerFileName.isEmpty())
        {
            file = new File(answerFileName);
        }
        else
        {
            answerFileName = map.get('answersTempFile')
            file = new File(map.get('iuh.update.set.path') + File.separator + answerFileName);
        }
        if (FileUtils.checkFileExist(file, false))
        {
            log.debug ("Read parameter " + map.get("iuh.answers.prefix") + "." + name + " from file: " + file);
            return PropertiesUtils.readPropertyFromFile(file, map.get("iuh.answers.prefix") + "." + name);
        }
        return null;
	}

}
