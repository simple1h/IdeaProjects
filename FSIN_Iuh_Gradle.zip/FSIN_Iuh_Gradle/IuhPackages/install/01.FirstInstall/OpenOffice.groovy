import groovy.util.logging.Log4j
import ru.datateh.jbr.iuh.AbstractExecute
import ru.datateh.jbr.iuh.utils.FileUtils
import ru.datateh.jbr.iuh.utils.PropertiesUtils

/**
 * @author etarakanov
 * Date: 06.02.15
 * Time: 15:47
 */

@Log4j
public class OpenOffice extends AbstractExecute
{
    private static String IUH_CONVERTER_TEMP = "br4j.dbmi.convertor.temp.dir";
    private static String IUH_OPEN_OFFICE_TEMP = "br4j.dbmi.openoffice.temp.dir";

    private static String IUH_CONVERTER_TEMP_DEFVAL = "data/ooconverter";
    private static String IUH_OPEN_OFFICE_TEMP_DEFVAL = "data/ooconverter";

    private static String CONVERTER_TEMP = "convertor.temp.dir";
    private static String OPEN_OFFICE_TEMP = "openoffice.temp.dir";
    private static String CONVERTOR_CACHE_PARAMETER = "convertor.cache.storage";

    private Map<String, String> properties;

    public void install() {
        log.info "OpenOffice is running... "

        File fileProperties = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'openoffice' + File.separator + 'pdfConvertor.properties');
        File exampleProperties = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'openoffice' + File.separator + 'pdfConvertor.properties.example');

        if (!FileUtils.checkFileExist(fileProperties, false) && FileUtils.checkFileExist(exampleProperties, true))
        {
            log.info "Property file: " + fileProperties + " missing. File will be created from copy: " + exampleProperties;
            FileUtils.copyFile(exampleProperties, fileProperties);
            if (!checkPropertiesValues(fileProperties)) {
                updateRequiredProperty(fileProperties);
            }
            checkRootLocation(fileProperties);
            map.putAll(properties);
            FileUtils.changeFilePermission(fileProperties, FileUtils.Permission.WRITE, false);
        }
    }

    private boolean checkRootLocation(File fileProperties)
    {
        File converterCache = new File(PropertiesUtils.readPropertyFromFile(fileProperties, CONVERTOR_CACHE_PARAMETER));
        if(!converterCache.isDirectory())
        {
            log.warn "Value of property: " + CONVERTOR_CACHE_PARAMETER + " in file: " + fileProperties + " is INVALID";
            return false;
        }
        return true;
    }

    private Map<String, String> collectProperties ()
    {
        if (properties == null)
        {
            properties = new HashMap<String, String>();
            properties.put(IUH_CONVERTER_TEMP,
                    getPropertyValue(IUH_CONVERTER_TEMP, map.get('br4j.jboss.configuration.path')
                            + File.separator + IUH_CONVERTER_TEMP_DEFVAL));
            properties.put(IUH_OPEN_OFFICE_TEMP,
                    getPropertyValue(IUH_OPEN_OFFICE_TEMP, map.get('br4j.jboss.configuration.path')
                            + File.separator + IUH_OPEN_OFFICE_TEMP_DEFVAL));
        }
        return properties
    }

    private boolean checkPropertiesValues (File propertiesFile)
    {
        if (PropertiesUtils.checkPropertyEquals(propertiesFile, collectProperties()).isEmpty()) {
            return true;
        }
        return false;
    }

    private void updateRequiredProperty(File propertiesFile)
    {
        log.info("Updating file: " + propertiesFile);
        List<String> fileLines = FileUtils.readLines(propertiesFile);
        log.info("Updating property: " + CONVERTER_TEMP);
        PropertiesUtils.updateProperty(fileLines, CONVERTER_TEMP, getTransformedPath(collectProperties().get(IUH_CONVERTER_TEMP)),
                "Edited by OpenOffice script at: " + new Date());
        log.info("Updating property: " + OPEN_OFFICE_TEMP);
        PropertiesUtils.updateProperty(fileLines, OPEN_OFFICE_TEMP, getTransformedPath(collectProperties().get(IUH_OPEN_OFFICE_TEMP)),
                "Edited by OpenOffice script at: " + new Date());
        FileUtils.storeLines(propertiesFile, fileLines);
        log.info("Updating file: " + propertiesFile + " finished");
    }

    private String getTransformedPath (String path)
    {
        File checkedPath = new File(path);
        if (checkedPath.isAbsolute()){
            return path;
        } else {
            return map.get('br4j.jboss.configuration.path') + File.separator + path;
        }
    }

    public static void main(String[] args) {
        new OpenOffice().start()
    }

}
