package ru.datateh.jbr.iuh.msg;

public class HarnessException extends Exception {
	
	private static final long serialVersionUID = 1L;
	
	private Message harnessMessage;
	
	public HarnessException(Message harnessMessage, Throwable t) {
		super(t);
		this.harnessMessage = harnessMessage;
	}
	
	public HarnessException(Message harnessMessage) {
		this.harnessMessage = harnessMessage;
	}

	public Message getHarnessMessage() {
		return harnessMessage;
	}

	public void setHarnessMessage(Message harnessMessage) {
		this.harnessMessage = harnessMessage;
	}

}
