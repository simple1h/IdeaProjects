package ru.datateh.jbr.iuh.enums;

public enum RunModes {
	
	INIT,
	
	CHECK,
	
	INSTALL,
	
	UNINSTALL

}
