package groovyTest

import com.aplana.dbmi.tests.base.system.impl.TestArgumentImpl
/**
 * @author etarakanov
 * Date: 30.09.14
 * Time: 12:43
 */

class Login extends BaseScriptRunnable {

    @Override
    void run()
    {
        def goToPortal = action('navigateToPortal','Перейти на страницу входа в систему',
                'Переход на страницу выполнен','','signInPage','','navigateTo')
        def goToPortalArgs = new TestArgumentImpl()
        goToPortalArgs.setName("url")
        goToPortalArgs.setStringValue(getSeleniumService().getBaseUrl() + "/portal")
        performWithException(goToPortal, goToPortalArgs)

        def setLogin = action('setLogin','Записать логина в поле ввода "Имя пользователя"',
                'Логин введен','','signInPage','loginField','setText')
        def setLoginArgs = new TestArgumentImpl()
        setLoginArgs.setName("login")
        setLoginArgs.setStringValue("shelkovnikova_ov")
        performWithException(setLogin, setLoginArgs)
    }
}

