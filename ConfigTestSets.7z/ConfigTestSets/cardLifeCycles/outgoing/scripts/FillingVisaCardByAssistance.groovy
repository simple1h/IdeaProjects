package cardLifeCycles.outgoing.scripts

import com.aplana.dbmi.tests.base.system.impl.BaseScriptRunnable

/**
 * @author etarakanov
 * Date: 10.10.14
 * Time: 11:25
 */
/**
 * скрипт заполнения карточки визирования и напраления ее в АРМ руководителя помощником согласующего
  */

public class FillingVisaCardByAssistance extends BaseScriptRunnable
{

    @Override
    void run()
    {
        String visaCardCode = getPropertyFromContext("visaCardCode")
//        String visaCardCode = "13261418"

        performWithException(
                action('openCard','Открыть карточку визирования с кодом: ' + visaCardCode, 'Карточка открыта','','outgoingSectionPage','','navigateTo'),
                argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=e&windowstate=normal&mode=view&MI_EDIT_CARD=" + visaCardCode)
        )

        performWithException(
                action('transferCardToEditMode','Перевод карточки \'Визирования\' в режим редактирования', 'Перевод выполнен','','mainCardPage','','navigateTo'),
                argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=9&windowstate=maximized&MI_ACTION_FIELD=MI_EDIT_CARD_ACTION&TAB_ID=200")
        )

        performWithException(
                action('setCurrentResolution','Установить текущее решение', 'Текущее решение установлено','','agreementData','currentResolution','setText'),
                argument("text", "empty", "решение ")
        )


        performWithException(action('clickChangeStatus','Нажать на кнопку изменить статус', 'Кнопка нажата','','buttonPanelPage','changeStatusButton','click'), null)

        performWithException(action('clickSendToARMManager','Нажать на кнопку "В АРМ руководителю"', 'Кнопка нажата','','buttonPanelPage','sendToARMManageru','click'), null)

        performUntilSuccess(15, 15000)
                {
                    performWithException(
                            action('openCard','Открыть карточку визирования с кодом: ' + visaCardCode, 'Карточка открыта','','outgoingSectionPage','','navigateTo'),
                            argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=e&windowstate=normal&mode=view&MI_EDIT_CARD=" + visaCardCode)
                    )

                    performWithException(action('clickCardInfoArrow','Раскрытие вкладки дополнительной информации', 'Вкладка раскрыта','','mainCardPage','infoHeaderButton','click'), null)

                    def template = performWithException(action('getTemplate','Получить типа шаблона карточки документа', 'Тип шаблона получен','','mainCardPage','templateLabel','getText'), null)
                    performWithException(
                            action('checkTemplate','Проверка типа шаблона карточки. Ожидается: Визирование', 'Проверка выполенена','','mainCardPage','templateLabel','compareText'),
                            argument("text", "empty", "Визирование"),template)

                    def cardState = performWithException(action('getCardState','Получить статус открытой карточки', 'Статус получен','','mainCardPage','cardStateLabel','getText'), null)
                    performWithException(
                            action('checkCardState','Проверка статуса карточки. Ожидается: Согласование', 'Проверка выполенена','','mainCardPage','cardStateLabel','compareText'),
                            argument("text", "empty", "Согласование"),cardState)
                }
    }
}
