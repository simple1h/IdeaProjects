#!/bin/bash

java -cp iuh.jar:${GROOVY_HOME}/embeddable/groovy-all-2.2.2.jar:$GROOVY_HOME/lib/ant-1.9.2.jar:$GROOVY_HOME/lib/ant-launcher-1.9.2.jar:$GROOVY_HOME/lib/commons-cli-1.2.jar ru.datateh.jbr.iuh.groovy.Main $*
