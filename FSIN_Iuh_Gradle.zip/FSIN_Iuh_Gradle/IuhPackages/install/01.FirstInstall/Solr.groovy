import groovy.util.logging.Log4j
import ru.datateh.jbr.iuh.AbstractExecute
import ru.datateh.jbr.iuh.utils.FileUtils
import ru.datateh.jbr.iuh.utils.PropertiesUtils

@Log4j
public class Solr extends AbstractExecute
{
    private static String IUH_ROOT_LOCATION = "br4j.dbmi.filestore.rootLocation";
    private static String IUH_NULL_URL_ROOT_LOCATION = "br4j.dbmi.filestore.nullUrlRootLocation";
    private static String IUH_CACHE_ROOT_LOCATION = "br4j.dbmi.filestore.cacheRootLocation";

    private static String ROOT_LOCATION = "store.rootLocation";
    private static String NULL_URL_ROOT_LOCATION = "store.nullUrlRootLocation";
    private static String CACHE_ROOT_LOCATION = "store.cacheRootLocation";

    private Map<String, String> properties;
	
	public void install() {
		log.info "Solr is running... "

        File fileProperties = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'solr' + File.separator + 'solrModule.properties');

        File exampleProperties = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'solr' + File.separator + 'solrModule.properties.example');

        if (!FileUtils.checkFileExist(fileProperties, false) && FileUtils.checkFileExist(exampleProperties, true))
        {
            log.info "Property file: " + fileProperties + " missing. File will be created from copy: " + exampleProperties;
            FileUtils.copyFile(exampleProperties, fileProperties);
            if (!checkPropertiesValues(fileProperties)) {
                updateRequiredProperty(fileProperties);
            }
            checkRootLocation(fileProperties);
            map.putAll(properties);
            FileUtils.changeFilePermission(fileProperties, FileUtils.Permission.WRITE, false);
        }
        else if(FileUtils.checkFileExist(fileProperties, false))
        {
            map.putAll(PropertiesUtils.readPropertiesMapFromFile(fileProperties,
                    Arrays.asList(ROOT_LOCATION, NULL_URL_ROOT_LOCATION, CACHE_ROOT_LOCATION)));
        }
    }



    private boolean checkRootLocation(File fileProperties)
    {
        File rootLocation = new File(collectProperties().get(IUH_ROOT_LOCATION));
        File cacheRootLocation = new File(collectProperties().get(IUH_CACHE_ROOT_LOCATION));
        if(!rootLocation.isDirectory())
        {
            log.warn "Value of property: " + ROOT_LOCATION + " in file: " + fileProperties + " is INVALID";
            return false;
        }
        if(!cacheRootLocation.isDirectory())
        {
            log.warn "Value of property: " + CACHE_ROOT_LOCATION + " in file: " + fileProperties + " is INVALID";
            return false;
        }
        return true;
    }

    private Map<String, String> collectProperties ()
    {
        if (properties == null)
        {
            properties = new HashMap<String, String>();
            properties.put(IUH_ROOT_LOCATION,
                    getPropertyValue(IUH_ROOT_LOCATION, null));
            properties.put(IUH_NULL_URL_ROOT_LOCATION,
                    getPropertyValue(IUH_NULL_URL_ROOT_LOCATION, null));
            properties.put(IUH_CACHE_ROOT_LOCATION,
                    getPropertyValue(IUH_CACHE_ROOT_LOCATION, null));
        }
        return properties
    }

    private boolean checkPropertiesValues (File propertiesFile)
    {
        if (PropertiesUtils.checkPropertyEquals(propertiesFile, collectProperties()).isEmpty()) {
            return true;
        }
        return false;
    }

    private void updateRequiredProperty(File propertiesFile)
    {
        log.info("Updating file: " + propertiesFile);
        List<String> fileLines = FileUtils.readLines(propertiesFile);
        log.info("Updating property: " + ROOT_LOCATION);
        PropertiesUtils.updateProperty(fileLines, ROOT_LOCATION, getTransformedPath(collectProperties().get(IUH_ROOT_LOCATION)),
                "Edited by Solr script at: " + new Date());
        log.info("Updating property: " + NULL_URL_ROOT_LOCATION);
        PropertiesUtils.updateProperty(fileLines, NULL_URL_ROOT_LOCATION, getTransformedPath(collectProperties().get(IUH_NULL_URL_ROOT_LOCATION)),
                "Edited by Solr script at: " + new Date());
        log.info("Updating property: " + CACHE_ROOT_LOCATION);
        PropertiesUtils.updateProperty(fileLines, CACHE_ROOT_LOCATION, getTransformedPath(collectProperties().get(IUH_CACHE_ROOT_LOCATION)),
                "Edited by Solr script at: " + new Date());
        FileUtils.storeLines(propertiesFile, fileLines);
        log.info("Updating file: " + propertiesFile + " finished");
    }

    private String getTransformedPath (String path)
    {
        File checkedPath = new File(path);
        if (checkedPath.isAbsolute()){
            return path;
        } else {
            return map.get('br4j.jboss.configuration.path') + File.separator + path;
        }
    }

    public static void main(String[] args) {
            new Solr().start();
    }

}