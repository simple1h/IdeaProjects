import groovy.util.logging.Log4j
import org.w3c.dom.Document
import org.w3c.dom.Element
import ru.datateh.jbr.iuh.AbstractExecute
import ru.datateh.jbr.iuh.utils.FileUtils
import ru.datateh.jbr.iuh.utils.PropertiesUtils

/**
 * @author etarakanov
 * Date: 10.02.15
 * Time: 18:40
 */
@Log4j
public class Replication extends AbstractExecute
{
    private static String IUH_SERVER_GUID = "br4j.dbmi.replication.ServerGUID";
    private static String IUH_INCOMING_FOLDER = "br4j.dbmi.replication.IncomingFolder";
    private static String IUH_OUTGOING_FOLDER = "br4j.dbmi.replication.OutgoingFolder";
    private static String IUH_REPLICATION_MEMBER_GUID = "br4j.dbmi.replication.GUID";

    private static String SERVER_GUID = "ServerGUID";
    private static String INCOMING_FOLDER = "IncomingFolder";
    private static String OUTGOING_FOLDER = "OutgoingFolder";
    private static String GUID = "GUID";

    private Map<String, String> properties;

    private List<String> guids;


    @Override
    void install() {
        log.info "Replication is running... "

        File fileProperties = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'replication' + File.separator + 'ReplicationNodeConfig.xml');

        File exampleProperties = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'replication' + File.separator + 'ReplicationNodeConfig.xml.example');

        File exampleProperties2 = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'replication' + File.separator + 'ReplicationTemplateConfig.xml.example');

        File fileProperties2 = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'replication' + File.separator + 'ReplicationTemplateConfig.xml');

        log.info "File: " + fileProperties2 + " will be created from copy: " + exampleProperties2;
        FileUtils.copyFile(exampleProperties2, fileProperties2);

        if (!FileUtils.checkFileExist(fileProperties, false) && FileUtils.checkFileExist(exampleProperties, true))
        {
            log.info "Property file: " + fileProperties + " missing. File will be created from copy: " + exampleProperties;
            FileUtils.copyFile(exampleProperties, fileProperties);
            if (!checkPropertiesValues(fileProperties)) {
                updateRequiredProperty(fileProperties);
            }
            FileUtils.changeFilePermission(fileProperties, FileUtils.Permission.WRITE, false);
        }
    }

    public static void main(String[] args) {
        new Replication().start()
    }

    private boolean checkPropertiesValues (File propertiesFile)
    {
        if (collectProperties().get(IUH_SERVER_GUID).equals(PropertiesUtils.readTagValueFromXmlFile(propertiesFile, SERVER_GUID)) &&
                collectProperties().get(IUH_INCOMING_FOLDER).equals(PropertiesUtils.readTagValueFromXmlFile(propertiesFile, INCOMING_FOLDER)) &&
                collectProperties().get(IUH_OUTGOING_FOLDER).equals(PropertiesUtils.readTagValueFromXmlFile(propertiesFile, OUTGOING_FOLDER)) &&
                !collectGUIDS().retainAll(readGUIDfromFile(propertiesFile)))
        {
            return true;
        }
        return false;
    }

    private Map<String, String> collectProperties ()
    {
        if (properties == null)
        {
            properties = new HashMap<String, String>();
            properties.put(IUH_SERVER_GUID, getPropertyValue(IUH_SERVER_GUID, null));
            properties.put(IUH_INCOMING_FOLDER,
                    getPropertyValue(IUH_INCOMING_FOLDER, null));
            properties.put(IUH_OUTGOING_FOLDER,
                    getPropertyValue(IUH_OUTGOING_FOLDER, null));
        }
        return properties
    }

    private List<String> collectGUIDS ()
    {
        if (guids == null) {
            int countGuids = Integer.parseInt(getPropertyValue(IUH_REPLICATION_MEMBER_GUID + ".count", null));
            guids = new ArrayList<String>();
            while (countGuids > 0)
            {
                guids.add(getPropertyValue(IUH_REPLICATION_MEMBER_GUID + ".number." + countGuids, null))
                countGuids--;
            }
        }
        return guids;
    }

    private static List<String> readGUIDfromFile (File propertiesFile)
    {
        Document document = PropertiesUtils.readXmlDocumentFromFile(propertiesFile);
        org.w3c.dom.NodeList nodeList = document.getElementsByTagName(GUID);
        List<String> result = new ArrayList<String>();
        Iterator<org.w3c.dom.Node> nodeIterator = nodeList.iterator();
        while (nodeIterator.hasNext())
        {
            result.add(nodeIterator.next().getTextContent());
        }
        return result;
    }

    private static void updateGUIDtoFile (File propertiesFile, List<String> guids)
    {
        Document document = PropertiesUtils.readXmlDocumentFromFile(propertiesFile);
        org.w3c.dom.Node replicationMember = document.getElementsByTagName("ReplicationMember").item(0);
        while (replicationMember.hasChildNodes())
            replicationMember.removeChild(replicationMember.getFirstChild());
        for(String giud : guids)
        {
            Element node = document.createElement(GUID);
            node.setTextContent(giud);
            replicationMember.appendChild(node);
        }
        PropertiesUtils.storeXmlDocumentToFile(propertiesFile,document);
    }

    private void updateRequiredProperty(File propertiesFile)
    {
        log.info("Updating file: " + propertiesFile);
        log.info("Updating property: " + SERVER_GUID);
        PropertiesUtils.updateXmlTagValueAndSave(propertiesFile, SERVER_GUID, collectProperties().get(IUH_SERVER_GUID));
        log.info("Updating property: " + INCOMING_FOLDER);
        PropertiesUtils.updateXmlTagValueAndSave(propertiesFile, INCOMING_FOLDER, getTransformedPath(collectProperties().get(IUH_INCOMING_FOLDER)));
        log.info("Updating property: " + OUTGOING_FOLDER);
        PropertiesUtils.updateXmlTagValueAndSave(propertiesFile, OUTGOING_FOLDER, getTransformedPath(collectProperties().get(IUH_OUTGOING_FOLDER)));
        log.info("Updating property: " + GUID);
        updateGUIDtoFile(propertiesFile, collectGUIDS());
        log.info("Updating file: " + propertiesFile + " finished");
    }

    private String getTransformedPath (String path)
    {
        File checkedPath = new File(path);
        if (checkedPath.isAbsolute()){
            return path;
        } else {
            return map.get('br4j.jboss.configuration.path') + File.separator + path;
        }
    }
}
