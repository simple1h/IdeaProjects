package ru.datateh.jbr.iuh.msg;

public enum MessageType {
	
	SUCCESS("success"),
	
	ERROR("error"),
	
	REJECT("reject"),
	
	UNDEFINED("undefined");
	
	String text;
	
	MessageType(String text) {
		this.text = text;
	}
	
	public String getText() {
		return text;
	}
	
	public static MessageType getMessageType(String str) {
		if(str.equalsIgnoreCase("success"))
			return SUCCESS;
		else if(str.equalsIgnoreCase("error"))
			return ERROR;
		else if(str.equalsIgnoreCase("reject"))
			return REJECT;
		else
			return UNDEFINED;
	}

}
