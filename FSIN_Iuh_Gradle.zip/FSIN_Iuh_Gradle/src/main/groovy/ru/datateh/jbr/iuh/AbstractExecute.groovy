package ru.datateh.jbr.iuh

import groovy.util.logging.Log4j
import org.apache.log4j.PropertyConfigurator
import org.apache.log4j.Logger;
import ru.datateh.jbr.iuh.msg.HarnessException
import ru.datateh.jbr.iuh.msg.Message
import ru.datateh.jbr.iuh.msg.MessageType
import ru.datateh.jbr.iuh.utils.FileUtils
import ru.datateh.jbr.iuh.utils.IuhUtils
import ru.datateh.jbr.iuh.utils.PropertiesUtils

@Log4j
abstract class AbstractExecute implements Phases {
	
	protected static Map<String, String> map

    private static final String CODE_WORD = "2734b4f0-86ec-40bb-b62c-94681a7cc95c";
	
	protected boolean force
	protected String run
	//protected boolean preRun
	
	protected ScriptExecutor exec = new ScriptExecutor()
	
	protected Message msg
	

	public void init() {}
	
	protected void initScript() {
		try {

			init()
				
		} catch(Exception e) {
			if(msg == null) {
				msg = new Message(MessageType.ERROR, e)
			}
			if(!force) {
				throw new Exception(e);
			}
		}
		
	}
	

	public boolean check() {
		return true
	}
	

	protected boolean checkScript() {
		
		initScript()
		
		try {
			
			if(!check()) {
				return false
			}
			return true
		} catch(Exception e) {
			if(msg == null) {
				msg = new Message(MessageType.ERROR, e)
			}
			if(!force) {
				throw new Exception(e);
			}
		}
		
	}
	

	public void install() {
		
	}
	

	protected void installScript() {
		
		if(!checkScript()) {
			msg = new Message(MessageType.REJECT, 'Script: ' + map.get('scriptDir') + ' has been rejected, maybe repeating')
			return
		}
		
		try {
			
			install()
				
		}
        catch (HarnessException e)
        {
            if(msg == null) {
                msg = e.getHarnessMessage();
            }
            log.error force
            if(!force) {
                throw new Exception(e);
            }
        }
        catch(Exception e) {
			if(msg == null) {
				msg = new Message(MessageType.ERROR, e)
			}
            log.error force
			if(!force) {
				throw new Exception(e);
			}
		}
		
	}
	

	public void uninstall() {}
	

	protected void uninstallScript() {
		
		checkScript()
		
		uninstall()
	}
	
	public void postInit() {
		/*map.put('preRun', 'false')
		Set<String> userValues = exec.getUserValues()
		log.debug 'userValues in postInit method: ' + userValues
		if(userValues != null) {
			map.put('userValues', StringUtils.collectionToString(userValues))
		}*/
	}
	
	
	public void finalize() {
		if(msg != null) {
			map.put('msgKey', msg.state)
			if(msg.text != null) {
				map.put('msgVal', msg.text.size() > 1024 ? msg.text.substring(0, 1024).replaceAll('\n', '') : msg.text.replaceAll('\n', ''))
			}
		}
		IuhUtils.mapToSharedFile(map)
	}
	
	
	protected void start() {
		LOG.error("Just entered getAggCatService");
		// ���������� ������������
        def config = new ConfigSlurper().parse(FileUtils.getLogConfigFile().toURI().toURL());
		PropertyConfigurator.configure(config.toProperties())
		
		map = IuhUtils.sharedFileToMap()
		force = map.get('iuh.mode.force') ? Boolean.valueOf(map.get('iuh.mode.force')) : false
//        log.info "force = " + force +  " iuh.mode.force = " + map.get('iuh.mode.force')
		run = map.get('iuh.mode.run').trim()
		//preRun = map.get('preRun') ? Boolean.valueOf(map.get('preRun')) : false
		//map.remove('userValues')

        map.put("iuh.answers.prefix", getAnswerPrefix());
		exec.setMap(map)
		
		try {
			/*if(preRun) {
				initScript()
				postInit()
			} else */
			if('install'.equalsIgnoreCase(run)) {
				installScript()
			} else if('check'.equalsIgnoreCase(run)) {
				checkScript()
			} else if('init'.equalsIgnoreCase(run)) {
				initScript()
			}  else {
				throw new IllegalArgumentException('Illegal mode value: ' + run)
			}
		} catch(Exception e) {
			log.error 'Error during the execution of the script: ' + e.getMessage()
			log.error 'Execution will continue if the parameter FORCE equals TRUE'
		}

		finalize()
	}

    /**
     * Возвращает значение свойства.<p>
     * Последовательность поиска значения:<p>
     * 1. карта свойств;<p>
     * 2. общий файл;<p>
     * 3. если включен режим интерактивности, запрашивает у пользователя и сохраняет его в общий файл;<p>
     * 4. значение по умолчанию.<p>
     * @param propertyName - имя свойства
     * @param defaultValue - значение свойства по умолчанию
     * @return значение свойства, если не найдено генерируется исключение {@link ru.datateh.jbr.iuh.msg.HarnessException}
     */
    protected String getPropertyValue(String propertyName, String defaultValue)
    {
        boolean isInteractive = Boolean.parseBoolean(getParam("iuh.mode.interactive"));
        String result = getParam(propertyName);
        if (result != null && !result.isEmpty()){return result;}
        result = getValue(propertyName);
        if (result != null && !result.isEmpty()){return result;}
        if (isInteractive) {
            result = getUserResponse(propertyName);
            if (result != null && !result.isEmpty()){
                putValue(propertyName, result);
                return result;
            }
        }
        result = defaultValue;
        if (result != null && !result.isEmpty()){return result;}
        log.error("Can not find parameter: " + propertyName);
        throw new HarnessException(new Message(MessageType.ERROR, "Can not find parameter: " + propertyName));
    }

    /**
     * Запрашивает значение параметра у пользователя
     * @param parameterName - имя параметра
     * @return - значение параметра
     * @throws java.io.IOException
     */
    protected static String getUserResponse (String parameterName) throws IOException {
            System.out.println(CODE_WORD + ": " + parameterName);
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String parameterValue = br.readLine();
            return  parameterValue;
    }

    /**
     * Проверяет значение указанного свойства в файле свойств, в случае отличия запрашивает у пользователя разрешение
     * на изменение значения, и изменяет при положительном ответе.
     * @param propertyFile - файл свойств
     * @param propertyName - имя свойства
     * @param propertyNewValue - новое значение свойства
     * @param comment - комментарий добавляемый при изменении значения свойства
     * @return true если значение свойства было изменено, иначе false
     */
    protected boolean  updatePropertyWithConfirm (File propertyFile, String propertyName, String propertyNewValue, String comment)
    {
        String propertyCurrentValue = PropertiesUtils.readPropertyFromFile(propertyFile, propertyName);
        if (!propertyCurrentValue.equals(propertyNewValue))
        {
            String confirm = getUserResponse("Current property: " + propertyName + " has value: " + propertyCurrentValue
            + ". Do you want update this property with value: " + propertyNewValue + "? y/n?");
            if ("y".equalsIgnoreCase(confirm))
            {
                PropertiesUtils.updatePropertyAndSave(propertyFile, propertyName ,propertyNewValue, comment);
                return true;
            }
        }
        return false;
    }

    /**
     * Проверяет наличие указанного свойства в файле свойств, в случае отсутствия запрашивает у пользователя разрешение
     * на добаление свойства, и добавляет при положительном ответе.
     * @param propertyFile файл свойств
     * @param propertyName имя свойства
     * @param propertyValue значение свойства
     * @param comment комментарий добавляемый при добавлении свойства
     * @return true если значение свойства было изменено, иначе false
     */
    protected boolean  createPropertyWithConfirm (File propertyFile, String propertyName, String propertyValue, String comment)
    {
        String propertyCurrentValue = PropertiesUtils.readPropertyFromFile(propertyFile, propertyName);
        if (propertyCurrentValue == null)
        {
            String confirm = getUserResponse("Property: " + propertyName + " is missing in file: " + propertyFile
                    + ". Do you want add this property with value: " + propertyValue + "? y/n?");
            if ("y".equalsIgnoreCase(confirm))
            {
                PropertiesUtils.addPropertyAndSave(propertyFile, propertyName ,propertyValue, comment);
                return true;
            }
        }
        return false;
    }

    /**
     * Проверяет наличие указанного свойства в файле свойств, в случае наличия запрашивает у пользователя разрешение
     * на удаление свойства, и удаляет при положительном ответе.
     * @param propertyFile файл свойств
     * @param propertyName имя свойства
     * @param comment строка комментарий, которая будет удалена из файла свойств, если будет найдена
     * @return true если значение свойства было изменено, иначе false
     */
    protected boolean  deletePropertyWithConfirm (File propertyFile, String propertyName, String comment)
    {
        String propertyCurrentValue = PropertiesUtils.readPropertyFromFile(propertyFile, propertyName);
        if (propertyCurrentValue != null)
        {
            String confirm = getUserResponse("Property: " + propertyName + " is present in file: " + propertyFile
                    + ". Do you want delete this property? y/n?");
            if ("y".equalsIgnoreCase(confirm))
            {
                PropertiesUtils.deletePropertyAndSave(propertyFile, propertyName, comment);
                return true;
            }
        }
        return false;
    }
	
	protected void setParam(name, value) {
		map.put(name, value)
	}
	
	
	protected String getParam(name) {
		map.get(name)
	}
	
	protected void putValue(String parameterName, String parameterValue) {
		exec.putValue(parameterName, parameterValue);
	}
	
	protected String getValue(String name) {
		return exec.getValue(name);
	}

    /**
     * выполнение sql-скрипта
     * @param sql sql-скрипт
     */
	protected void execSql(String sql) {
		exec.execSql(sql);
	}

    /**
     * выполнение sql-скрипта из файла
     * @param file имя файла. Файл должен находтся в папке packageName/data
     */
	protected void execSqlFromFile(String file) {
		exec.execSqlFromFile(file);
	}

    private String getAnswerPrefix ()
    {
        String className = this.getClass().getName();
        File scriptPath = new File (this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath());
        File suitePath = new File (scriptPath.getParent());
        String packageName = scriptPath.getName();
        String suiteName = suitePath.getName();
        String prefix = suiteName + "." + packageName + "." + className;
        return prefix;
    }

}
