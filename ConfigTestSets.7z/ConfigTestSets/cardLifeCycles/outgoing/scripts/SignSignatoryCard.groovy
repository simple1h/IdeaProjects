package cardLifeCycles.outgoing.scripts

import com.aplana.dbmi.tests.base.system.impl.BaseScriptRunnable

/**
 * @author etarakanov
 * Date: 10.10.14
 * Time: 16:11
 */
/**
 * скрипт подписания карточки подписи подписантом
 */
public class SignSignatoryCard extends BaseScriptRunnable
{
    @Override
    void run()
    {
        String cardCode = getPropertyFromContext("cardCode")
        String signatoryCardCode = getPropertyFromContext("signatoryCardCode")
//        String cardCode = "13261424"
//        String signatoryCardCode = "13261437"

        performWithException(
                action('openCard','Открыть карточку с кодом: ' + cardCode, 'Карточка открыта','','outgoingSectionPage','','navigateTo'),
                argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=e&windowstate=normal&mode=view&MI_EDIT_CARD=" + cardCode))

        performWithException(
                action('openSigningTab','Переход к вкладке подписание', 'Переход выполнен','','outgoingSectionPage','','navigateTo'),
                argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=1&MI_ACTION_FIELD=CHANGE_TAB_CARD_ACTION&TAB_ID=285"))

        performWithException(action('openSignatoryCard','Открытие карточки подписания', 'Карточка открыта','','signingSection','signatoryFI','click'), null)

        performWithException(action('clickChangeStatus','Нажать на кнопку изменить статус', 'Кнопка нажата','','buttonPanelPage','changeStatusButton','click'), null)

        performWithException(action('clickSendToARMManager','Нажать на кнопку "Согласен"', 'Кнопка нажата','','buttonPanelPage','signButton','click'), null)

        performWithError{
                    performWithException(action('cancelEcp','Отменить ЭЦП', 'Кнопка нажата','','mainCardPage','cancelEcp','click'), null)
                }

        performUntilSuccess(15, 15000)
                {
                    performWithException(
                            action('openCard','Открыть карточку с кодом: ' + cardCode, 'Карточка открыта','','outgoingSectionPage','','navigateTo'),
                            argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=e&windowstate=normal&mode=view&MI_EDIT_CARD=" + signatoryCardCode))


                    performWithException(action('clickCardInfoArrow','Раскрытие вкладки дополнительной информации', 'Вкладка раскрыта','','signingSection','infoHeaderButton','click'), null)

                    performWithException(
                            action('checkTemplate','Проверка типа шаблона карточки. Ожидается: Подпись', 'Проверка выполенена','','signingSection','templateLabel','compareText'),
                            argument("text", "empty", "Подпись"),
                            performWithException(action('getTemplate','Получить типа шаблона карточки документа', 'Тип шаблона получен','','signingSection','templateLabel','getText'), null))

                    performWithException(
                            action('checkCardState','Проверка статуса карточки. Ожидается: Подписано', 'Проверка выполенена','','signingSection','cardStateLabel','compareText'),
                            argument("text", "empty", "Подписано"),
                            performWithException(action('getCardState','Получить статус открытой карточки', 'Статус получен','','signingSection','cardStateLabel','getText'), null))
                }

        performWithException(
                action('backAction','Переход назад', 'Переход выполнен','','mainCardPage','','navigateTo'),
                argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=9&windowstate=normal&MI_ACTION_FIELD=MI_BACK_ACTION"))

        performUntilSuccess(15, 15000)
                {
                    performWithException(
                            action('openCard','Открыть карточку с кодом: ' + cardCode, 'Карточка открыта','','outgoingSectionPage','','navigateTo'),
                            argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=e&windowstate=normal&mode=view&MI_EDIT_CARD=" + cardCode))

                    performWithException(action('clickCardInfoArrow','Раскрытие вкладки дополнительной информации', 'Вкладка раскрыта','','signingSection','infoHeaderButton','click'), null)

                    performWithException(
                            action('checkTemplate','Проверка типа шаблона карточки. Ожидается: Исходящий', 'Проверка выполенена','','signingSection','templateLabel','compareText'),
                            argument("text", "empty", "Исходящий"),
                            performWithException(action('getTemplate','Получить типа шаблона карточки документа', 'Тип шаблона получен','','signingSection','templateLabel','getText'), null))

                    performWithException(
                            action('checkCardState','Проверка статуса карточки. Ожидается: Регистрация', 'Проверка выполенена','','signingSection','cardStateLabel','compareText'),
                            argument("text", "empty", "Регистрация"),
                            performWithException(action('getCardState','Получить статус открытой карточки', 'Статус получен','','signingSection','cardStateLabel','getText'), null))
                }


    }
}

