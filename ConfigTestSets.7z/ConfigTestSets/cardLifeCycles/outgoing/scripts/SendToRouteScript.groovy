package cardLifeCycles.outgoing.scripts
import com.aplana.dbmi.tests.base.system.exceptions.PageException
import com.aplana.dbmi.tests.base.system.impl.BaseScriptRunnable
import com.aplana.dbmi.tests.base.system.impl.TestArgumentImpl
/**
 * @author etarakanov
 * Date: 03.10.14
 * Time: 17:34
 */

public class SendToRouteScript extends BaseScriptRunnable
{
    @Override
    void run()
    {
        String cardCode = getPropertyFromContext("cardCode")
//        def cardCode = "13261016"

        def openCard = action('openCard','Открыть карточку с кодом: ' + cardCode,
                'Карточка открыта','','outgoingSectionPage','','navigateTo')
        def openCardArgs = new TestArgumentImpl()
        openCardArgs.setName("url")
        openCardArgs.setStringValue(getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=e&windowstate=normal&mode=view&MI_EDIT_CARD=" + cardCode)
        performWithException(openCard, openCardArgs)

        def clickChangeStatus = action('clickChangeStatus','Нажать на кнопку изменить статус',
                'Кнопка нажата','','buttonPanelPage','changeStatusButton','click')
        performWithException(clickChangeStatus, null)

        def clickSendToRoute = action('clickSendToRoute','Нажать на кнопку "Отправить по маршруту"',
                'Кнопка нажата','','buttonPanelPage','sendToRouteMenu','click')
        performWithException(clickSendToRoute, null)

        try
        {
            def cancelEcp = action('cancelEcp','Отменить ЭЦП',
                    'Кнопка нажата','','createCardPage','cancelEcp','click')
            performWithException(cancelEcp, null)
        }
        catch (PageException e)
        {}

        performUntilSuccess(15, 15000)
                {
                    performWithException(openCard, openCardArgs)

                    def clickCardInfoArrow = action('clickCardInfoArrow','Раскрытие вкладки дополнительной информации',
                            'Вкладка раскрыта','','createCardPage','infoHeaderButton','click')
                    performWithException(clickCardInfoArrow, null)

                    def getTemplate = action('getTemplate','Получить типа шаблона карточки документа',
                            'Тип шаблона получен','','createCardPage','templateLabel','getText')
                    def template = performWithException(getTemplate, null)

                    def checkTemplate = action('checkTemplate','Проверка типа шаблона карточки. Ожидается: Исходящий',
                            'Проверка выполенена','','createCardPage','templateLabel','compareText')
                    def checkTemplateArgs = new TestArgumentImpl()
                    checkTemplateArgs.setName("text")
                    checkTemplateArgs.setStringValue("Исходящий")
                    performWithException(checkTemplate, checkTemplateArgs, template)

                    def getCardState = action('getCardState','Получить статус открытой карточки',
                            'Статус получен','','createCardPage','cardStateLabel','getText')
                    def cardState = performWithException(getCardState, null)

                    def checkCardState = action('checkCardState','Проверка статуса карточки. Ожидается: Подписание',
                            'Проверка выполенена','','createCardPage','cardStateLabel','compareText')
                    def checkCardStateArgs = new TestArgumentImpl()
                    checkCardStateArgs.setName("text")
                    checkCardStateArgs.setStringValue("Подписание")
                    performWithException(checkCardState, checkCardStateArgs, cardState)
                }
    }
}
