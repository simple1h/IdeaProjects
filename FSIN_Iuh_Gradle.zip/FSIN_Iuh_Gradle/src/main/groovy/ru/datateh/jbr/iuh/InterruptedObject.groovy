package ru.datateh.jbr.iuh

class InterruptedObject {
	
	private static InterruptedObject instance = new InterruptedObject()
	
	private InterruptedObject() {
	}
	
	private volatile boolean flag
	private volatile boolean finished
	
	public static InterruptedObject getInstance() {
		return instance
	}


	public boolean isFlag() {
		return flag;
	}

	public void setFlag(boolean flag) {
		this.flag = flag;
	}

	public boolean isFinished() {
		return finished;
	}

	public void setFinished(boolean finished) {
		this.finished = finished;
	}

}
