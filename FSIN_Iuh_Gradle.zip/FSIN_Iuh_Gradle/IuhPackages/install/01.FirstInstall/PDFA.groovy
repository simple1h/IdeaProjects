import groovy.util.logging.Log4j
import ru.datateh.jbr.iuh.AbstractExecute
import ru.datateh.jbr.iuh.utils.FileUtils
@Log4j
public class PDFA extends AbstractExecute
{
    public void install()
    {
        log.info "PDFA is running... "
        File exampleProperties = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'PDFAConverter' + File.separator + 'pdfaConverter.properties.example');
        File fileProperties = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'PDFAConverter' + File.separator + 'pdfaConverter.properties');
        log.info "File: " + fileProperties + " will be created from copy: " + exampleProperties;
        FileUtils.copyFile(exampleProperties, fileProperties);
        FileUtils.changeFilePermission(fileProperties, FileUtils.Permission.WRITE, false);
    }

    public static void main(String[] args) {
        new PDFA().start()
    }
}
