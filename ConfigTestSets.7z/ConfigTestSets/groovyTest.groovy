import com.aplana.dbmi.tests.base.system.interfaces.busines.TestCaseGroovyExt
/**
 * @author etarakanov
 * Date: 29.09.14
 * Time: 15:52
 */
def test = testCase as TestCaseGroovyExt;
println "Hello from groovy script"
println(testCase.getScriptResource())