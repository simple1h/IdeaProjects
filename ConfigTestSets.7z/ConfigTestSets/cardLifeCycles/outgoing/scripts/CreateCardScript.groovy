package cardLifeCycles.outgoing.scripts

import com.aplana.dbmi.tests.base.system.impl.BaseScriptRunnable
import com.aplana.dbmi.tests.base.system.impl.TestArgumentImpl
/**
 * @author etarakanov
 * Date: 01.10.14
 * Time: 16:23
 */

/**
 * скрипт создания карточки исходящего документа
 */

public class CreateCardScript extends BaseScriptRunnable {

    def utils = new Utils()

    @Override
    void run()
    {
        def goToOutgoing = action('goToOutgoing','Перейти в раздел "Исходящие"',
                'Переход на страницу выполнен','','personaCabinetPage','','navigateTo')
        def goToOutgoingArgs = new TestArgumentImpl()
        goToOutgoingArgs.setName("url")
        goToOutgoingArgs.setStringValue(getSeleniumService().getBaseUrl() + "/portal/auth/portadriverl/dbmi/outcome/by-num")
        performWithException(goToOutgoing, goToOutgoingArgs)

        def goToCreate = action('goToCreate','Перейти к созданию карточки документа шаблона "Исходящие"',
                'Переход на страницу выполнен','','outgoingSectionPage','','navigateTo')
        def goToCreateArgs = new TestArgumentImpl()
        goToCreateArgs.setName("url")
        goToCreateArgs.setStringValue(getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=e&windowstate=normal&mode=view&MI_BACK_URL_FIELD=%2Fportal%2Fauth%2Fportal%2Fdbmi%2Foutcome%2Fby-num%2FCardListWindow%3Faction%3D2&MI_CREATE_CARD=364")
        performWithException(goToCreate, goToCreateArgs)

        def clickCardInfoArrow = action('clickCardInfoArrow','Раскрытие вкладки дополнительной информации',
                'Вкладка раскрыта','','createCardPage','infoHeaderButton','click')
        performWithException(clickCardInfoArrow, null)

        def getTemplate = action('getTemplate','Получить типа шаблона карточки документа',
                'Тип шаблона получен','','createCardPage','templateLabel','getText')
        def template = performWithException(getTemplate, null)

        def checkTemplate = action('checkTemplate','Проверка типа шаблона карточки. Ожидается: Исходящий',
                'Проверка выполенена','','createCardPage','templateLabel','compareText')
        def checkTemplateArgs = new TestArgumentImpl()
        checkTemplateArgs.setName("text")
        checkTemplateArgs.setStringValue("Исходящий")
        performWithException(checkTemplate, checkTemplateArgs, template)

        def getCardState = action('getCardState','Получить статус открытой карточки',
                'Статус получен','','createCardPage','cardStateLabel','getText')
        def cardState = performWithException(getCardState, null)

        def checkCardState = action('checkCardState','Проверка статуса карточки',
                'Проверка выполенена','','createCardPage','cardStateLabel','compareText')
        def checkCardStateArgs = new TestArgumentImpl()
        checkCardStateArgs.setName("text")
        checkCardStateArgs.setStringValue("Подготовка")
        performWithException(checkCardState, checkCardStateArgs, cardState)

        def getCardCode = action('getCardCode','Получение кода открытой карточки',
                'Код карточки получен','','createCardPage','cardCodeLabel','getText')
        def cardCode = performWithException(getCardCode, null)

        storePropertyInContext("cardCode":cardCode.getStringValue())

        utils.attachFile("file.doc", true)
        Thread.sleep(4000)
        utils.attachFile("file.pdf", false)
        Thread.sleep(4000)

        def setTypeDocument = action('setTypeDocument','Установить тип документа',
                'Тип докумнета установлен','','createCardPage','typeDocument','selectText')
        def setTypeDocumentArgs = new TestArgumentImpl()
        setTypeDocumentArgs.setName("text")
        setTypeDocumentArgs.setStringValue("Письмо")
        performWithException(setTypeDocument, setTypeDocumentArgs)

        def setJournalRegistration = action('setJournalRegistration','Установить журнал регистрации',
                'Журнал установлен','','createCardPage','journalRegistration','selectText')
        def setJournalRegistrationArgs = new TestArgumentImpl()
        setJournalRegistrationArgs.setName("text")
        setJournalRegistrationArgs.setStringValue("Журнал учета исходящих документов")
        performWithException(setJournalRegistration, setJournalRegistrationArgs)

        def setIndexNomenclature = action('setIndexNomenclature','Установить индекс номенклатуры',
                'Индекс номенклатуры установлен','','createCardPage','indexNomenclatures','selectText')
        def setIndexNomenclatureArgs = new TestArgumentImpl()
        setIndexNomenclatureArgs.setName("text")
        setIndexNomenclatureArgs.setStringValue("1-10-Приказы Минюста России по основной деятельности. Копии")
        performWithException(setIndexNomenclature, setIndexNomenclatureArgs)

        def clearUrgencyCategory = action('clearUrgencyCategory','Очистить поле "Категория срочности"',
                'Поле "Категория срочности" очищешо','','createCardPage','urgency','clearText')
        performWithException(clearUrgencyCategory, null)

        def setUrgencyCategory = action('setUrgencyCategory','Установить категорию срочности',
                'Категория срочности установлена','','createCardPage','urgency','selectText')
        def setUrgencyCategoryArgs = new TestArgumentImpl()
        setUrgencyCategoryArgs.setName("text")
        setUrgencyCategoryArgs.setStringValue("Срочно")
        performWithException(setUrgencyCategory, setUrgencyCategoryArgs)

        def setSummary = action('setSummary','Установить краткое содержание',
                'Краткое содеражание установлено','','createCardPage','summary','setText')
        def setSummaryArgs = new TestArgumentImpl()
        setSummaryArgs.setName("text")
        setSummaryArgs.setStringValue("Краткое содержание Исходящего")
        performWithException(setSummary, setSummaryArgs)

        def setSignatory = action('setSignatory','Установить ФИО Пописанта',
                'ФИО Подписанта установлено','','createCardPage','signatory','selectText')
        def setSignatoryArgs = new TestArgumentImpl()
        setSignatoryArgs.setName("text")
        setSignatoryArgs.setStringValue("Цатуров Владислав Владимирович")
        performWithException(setSignatory, setSignatoryArgs)

        def setDestination = action('setDestination','Установить Получатель исходящего',
                'Получатель исходящего установлен','','createCardPage','destination','selectText')
        def setDestinationArgs = new TestArgumentImpl()
        setDestinationArgs.setName("text")
        setDestinationArgs.setStringValue("(021.Казанский (Приволжский) федеральный университет)")
        performWithException(setDestination, setDestinationArgs)

        def closeCard = action('closeCard','Закрыть карточку',
                'Карточка закрыта','','createCardPage','closeCardButton','click')
        performWithException(closeCard, null)

        def acceptEditCard = action('acceptEditCard','Подтвердить изменения карточки',
                'Изменения подтверждены','','createCardPage','acceptEditButton','click')
        performWithException(acceptEditCard, null)

    }


    private class Utils
    {
        void attachFile(String local_name, boolean is_prime)
        {
            def clickAttachFile = action('clickAttachFile','Нажать на кнопке "Добавить" вложение',
                    'кнопка нажата','','createCardPage','attachFileButton','click')
            performWithException(clickAttachFile, null)

            def curDir = getPropertyFromContext("user.dir")

            def setFilePath = action('setFilePath','Установить путь к файлу',
                    'Путь установлен','','attachFilePage','filePathField','setText')
            def setFilePathArgs = new TestArgumentImpl()
            setFilePathArgs.setName("path")
            setFilePathArgs.setStringValue(curDir + File.separator + local_name)
            performWithException(setFilePath, setFilePathArgs)

            if (is_prime)
            {
                def choseMain = action('choseMain','Нажать на кнопке "Основной',
                        'кнопка нажата','','attachFilePage','mainDocChose','click')
                performWithException(choseMain, null)
            }

            def clickLoadFile = action('clickLoadFile','Нажать на кнопке "Загрузить" вложение',
                    'кнопка нажата','','attachFilePage','loadFileButton','click')
            performWithException(clickLoadFile, null)
        }
    }
}


