package ru.datateh.jbr.iuh.init

import groovy.util.logging.Log4j
import org.apache.log4j.PropertyConfigurator
import ru.datateh.jbr.iuh.AbstractExecute
import ru.datateh.jbr.iuh.msg.Message
import ru.datateh.jbr.iuh.msg.MessageType
import ru.datateh.jbr.iuh.utils.FileUtils
import ru.datateh.jbr.iuh.utils.IuhUtils

@Log4j
public abstract class AbstractInit extends AbstractExecute {
	
	@Override
	@Deprecated
	final public boolean check() {}

	@Override
	@Deprecated
	final public void install() {}

	@Override
	@Deprecated
	final public void uninstall() {}
	
	public void start() {
		
		// ���������� ������������
        def config = new ConfigSlurper().parse(FileUtils.getLogConfigFile().toURI().toURL());
		PropertyConfigurator.configure(config.toProperties())
		
		map = IuhUtils.sharedFileToMap()
		force = map.get('iuh.mode.force') ? Boolean.valueOf(map.get('iuh.mode.force')) : false
//        log.info "force = " + force +  " iuh.mode.force = " + map.get('iuh.mode.force')
		//preRun = map.get('preRun') ? Boolean.valueOf(map.get('preRun')) : false
		exec.setMap(map)
		
		try {
			
			//if(preRun) {
				initScript()
			/*	postInit()
			}*/
			
		} catch(Exception e) {
			log.error 'Error during the execution of the script: ' + e.getMessage()
			log.error 'Execution will continue if the parameter FORCE equals TRUE'
		}
		
		finalize()
	}
	
	protected void initScript() {
		
		try {
			
			init()
			
		} catch(Exception e) {
			if(msg == null) {
				msg = new Message(MessageType.ERROR, e)
			}
			if(!force) {
				throw new Exception(e);
			}
		}
	}

}
