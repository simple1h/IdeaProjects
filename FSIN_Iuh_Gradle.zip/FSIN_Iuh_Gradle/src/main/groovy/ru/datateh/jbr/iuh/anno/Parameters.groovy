package ru.datateh.jbr.iuh.anno

import java.lang.annotation.*

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@interface Parameters {
	
	String[] userInput() default [];
	String vmArgs() default '';
	boolean runAsAdmin() default false;
}
