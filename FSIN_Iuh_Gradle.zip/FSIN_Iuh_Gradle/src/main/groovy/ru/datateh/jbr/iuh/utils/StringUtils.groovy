package ru.datateh.jbr.iuh.utils
import groovy.util.logging.Log4j

@Log4j
class StringUtils {
	
	static String collectionToString(Collection<String> col) {
		log.debug 'Convert collection ' + col + ' to string'
		StringBuilder sb = new StringBuilder()
		for(Iterator<String> iter = col.iterator(); iter.hasNext();) {
			sb.append(iter.next())
			if(iter.hasNext()) {
				sb.append(',')
			}
		}
		return sb.toString()
	}
	
	static boolean isEmpty(String str) {
		if(str == null
			|| str.isEmpty()) {
			return true;
		}
		return false;
	}
}
