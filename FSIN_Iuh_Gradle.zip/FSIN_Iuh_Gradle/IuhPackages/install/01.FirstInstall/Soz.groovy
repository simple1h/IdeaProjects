import groovy.util.logging.Log4j
import ru.datateh.jbr.iuh.AbstractExecute
import ru.datateh.jbr.iuh.utils.FileUtils
import ru.datateh.jbr.iuh.utils.PropertiesUtils

/**
 * @author etarakanov
 * Date: 27.03.2015
 * Time: 13:07
 */
@Log4j
public class Soz extends AbstractExecute
{
    private static String IUH_EXPORT_DIRECTORY = "br4j.dbmi.soz.export.directory";
    private static String IUH_EXPORT_DIRECTORY_OK = "br4j.dbmi.soz.export.directory.result.ok";
    private static String IUH_EXPORT_DIRECTORY_FAIL = "br4j.dbmi.soz.export.directory.result.fail";
    private static String IUH_SERVER_URL = "br4j.dbmi.soz.server.url";
    private static String IUH_IN_DERECTORY = "br4j.dbmi.soz.in.directory";

    private static String EXPORT_DIRECTORY = "soz.export.directory";
    private static String EXPORT_DIRECTORY_OK = "soz.export.directory.result.ok";
    private static String EXPORT_DIRECTORY_FAIL = "soz.export.directory.result.fail";
    private static String SERVER_URL = "soz.server.url";
    private static String IN_DERECTORY = "soz.in.directory";

    private Map<String, String> properties;

    @Override
    void install() {
        log.info "Soz is running... "

        File fileProperties = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'soz' + File.separator + 'config.properties');

        File exampleProperties = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'soz' + File.separator + 'config.properties.example');

        if (!FileUtils.checkFileExist(fileProperties, false) && FileUtils.checkFileExist(exampleProperties, true))
        {
            log.info "Property file: " + fileProperties + " missing. File will be created from copy: " + exampleProperties;
            FileUtils.copyFile(exampleProperties, fileProperties);
            if (!checkPropertiesValues(fileProperties)) {
                updateRequiredProperty(fileProperties);
            }
            FileUtils.changeFilePermission(fileProperties, FileUtils.Permission.WRITE, false);
        }
    }

    private Map<String, String> collectProperties ()
    {
        if (properties == null)
        {
            properties = new HashMap<String, String>();
            properties.put(IUH_EXPORT_DIRECTORY, getPropertyValue(IUH_EXPORT_DIRECTORY,  null));
            properties.put(IUH_EXPORT_DIRECTORY_OK, getPropertyValue(IUH_EXPORT_DIRECTORY_OK,  null));
            properties.put(IUH_EXPORT_DIRECTORY_FAIL, getPropertyValue(IUH_EXPORT_DIRECTORY_FAIL,  null));
            properties.put(IUH_SERVER_URL, getPropertyValue(IUH_SERVER_URL, null));
            properties.put(IUH_IN_DERECTORY, getPropertyValue(IUH_IN_DERECTORY,  null));
        }
        return properties
    }

    private boolean checkPropertiesValues (File propertiesFile)
    {
        if (PropertiesUtils.checkPropertyEquals(propertiesFile, collectProperties()).isEmpty()) {
            return true;
        }
        return false;
    }

    private void updateRequiredProperty(File propertiesFile)
    {
        log.info("Updating file: " + propertiesFile);
        List<String> fileLines = FileUtils.readLines(propertiesFile);
        log.info("Updating property: " + EXPORT_DIRECTORY);
        PropertiesUtils.updateProperty(fileLines, EXPORT_DIRECTORY, getTransformedPath(collectProperties().get(IUH_EXPORT_DIRECTORY)),
                "Edited by Soz script at: " + new Date());
        log.info("Updating property: " + EXPORT_DIRECTORY_OK);
        PropertiesUtils.updateProperty(fileLines, EXPORT_DIRECTORY_OK, getTransformedPath(collectProperties().get(IUH_EXPORT_DIRECTORY_OK)),
                "Edited by Soz script at: " + new Date());
        log.info("Updating property: " + EXPORT_DIRECTORY_FAIL);
        PropertiesUtils.updateProperty(fileLines, EXPORT_DIRECTORY_FAIL, getTransformedPath(collectProperties().get(IUH_EXPORT_DIRECTORY_FAIL)),
                "Edited by Soz script at: " + new Date());
        log.info("Updating property: " + SERVER_URL);
        PropertiesUtils.updateProperty(fileLines, SERVER_URL, collectProperties().get(IUH_SERVER_URL),
                "Edited by Soz script at: " + new Date());
        log.info("Updating property: " + IN_DERECTORY);
        PropertiesUtils.updateProperty(fileLines, IN_DERECTORY, getTransformedPath(collectProperties().get(IUH_IN_DERECTORY)),
                "Edited by Soz script at: " + new Date());
        FileUtils.storeLines(propertiesFile, fileLines);
        log.info("Updating file: " + propertiesFile + " finished");
    }

    private String getTransformedPath (String path)
    {
        File checkedPath = new File(path);
        if (checkedPath.isAbsolute()){
            return path;
        } else {
            return map.get('br4j.jboss.configuration.path') + File.separator + path;
        }
    }

    public static void main(String[] args) {
        new Soz().start()
    }
}

