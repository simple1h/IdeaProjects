import groovy.util.logging.Log4j
import ru.datateh.jbr.iuh.AbstractExecute
import ru.datateh.jbr.iuh.utils.FileUtils

/**
 * @author etarakanov
 * Date: 27.03.2015
 * Time: 17:25
 */
@Log4j
public class CardSignature extends AbstractExecute
{
    public void install()
    {
        log.info "CardSignature is running... "
        File exampleProperties = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'card' + File.separator + 'signature' + File.separator + 'certChecking.properties.example');
        File exampleProperties1 = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'card' + File.separator + 'signature' + File.separator + 'crypto.properties.example');
        File exampleProperties2 = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'card' + File.separator + 'signature' + File.separator + 'cryptoLayer.properties.example');
        File fileProperties = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'card' + File.separator + 'signature' + File.separator + 'certChecking.properties');
        File fileProperties1 = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'card' + File.separator + 'signature' + File.separator + 'crypto.properties');
        File fileProperties2 = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'card' + File.separator + 'signature' + File.separator + 'cryptoLayer.properties');
        log.info "File: " + fileProperties + " will be created from copy: " + exampleProperties;
        FileUtils.copyFile(exampleProperties, fileProperties);
        FileUtils.changeFilePermission(fileProperties, FileUtils.Permission.WRITE, false);
        log.info "File: " + fileProperties1 + " will be created from copy: " + exampleProperties1;
        FileUtils.copyFile(exampleProperties1, fileProperties1);
        FileUtils.changeFilePermission(fileProperties1, FileUtils.Permission.WRITE, false);
        log.info "File: " + fileProperties2 + " will be created from copy: " + exampleProperties2;
        FileUtils.copyFile(exampleProperties2, fileProperties2);
        FileUtils.changeFilePermission(fileProperties2, FileUtils.Permission.WRITE, false);
    }

    public static void main(String[] args) {
        new CardSignature().start()
    }
}