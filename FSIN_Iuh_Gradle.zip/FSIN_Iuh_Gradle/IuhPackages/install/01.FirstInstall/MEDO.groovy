import groovy.util.logging.Log4j
import ru.datateh.jbr.iuh.AbstractExecute
import ru.datateh.jbr.iuh.utils.FileUtils

/**
 * @author etarakanov
 * Date: 10.02.15
 * Time: 14:58
 */
@Log4j
public class MEDO extends AbstractExecute
{
    private static String IUH_IN_FOLDER = "br4j.dbmi.medo.InFolder";
    private static String IUH_IN_FOLDER_PROCESSED = "br4j.dbmi.medo.InFolderProcessed";
    private static String IUH_IN_FOLDER_DISCARDED = "br4j.dbmi.medo.InFolderDiscarded";
    private static String IUH_OUT_FOLDER_EXPORT = "br4j.dbmi.medo.outFolderExport";
    private static String IUH_TICKETS_PATH = "br4j.dbmi.medo.ticketsPath";
    private static String IUH_PROCESSED_TICKETS_PATH = "br4j.dbmi.medo.processedTicketsPath";

    private static String IN_FOLDER = "InFolder";
    private static String IN_FOLDER_PROCESSED = "InFolderProcessed";
    private static String IN_FOLDER_DISCARDED = "InFolderDiscarded";
    private static String OUT_FOLDER_EXPORT = "outFolderExport";
    private static String TICKETS_PATH = "ticketsPath";
    private static String PROCESSED_TICKETS_PATH = "processedTicketsPath";

    private Map<String, String> properties;

    @Override
    public void install() {
        log.info "MEDO is running... "

        File fileProperties = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'medo' + File.separator + 'options.properties');
        File exampleProperties = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'medo' + File.separator + 'options.properties.example');

        if (!FileUtils.checkFileExist(fileProperties, false) && FileUtils.checkFileExist(exampleProperties, true))
        {
            log.info "Property file: " + fileProperties + " missing. File will be created from copy: " + exampleProperties;
            FileUtils.copyFile(exampleProperties, fileProperties);
            if (!checkPropertiesValues(fileProperties)) {
                updateRequiredProperty(fileProperties);
            }
            FileUtils.changeFilePermission(fileProperties, FileUtils.Permission.WRITE, false);
        }
    }

    public static void main(String[] args) {
        new MEDO().start()
    }

    private Map<String, String> collectProperties ()
    {
        if (properties == null)
        {
            properties = new HashMap<String, String>();
            properties.put(IUH_IN_FOLDER,
                    getPropertyValue(IUH_IN_FOLDER, null));
            properties.put(IUH_IN_FOLDER_PROCESSED,
                    getPropertyValue(IUH_IN_FOLDER_PROCESSED, null));
            properties.put(IUH_IN_FOLDER_DISCARDED,
                    getPropertyValue(IUH_IN_FOLDER_DISCARDED, null));
            properties.put(IUH_OUT_FOLDER_EXPORT,
                    getPropertyValue(IUH_OUT_FOLDER_EXPORT, null));
            properties.put(IUH_TICKETS_PATH,
                    getPropertyValue(IUH_TICKETS_PATH, null));
            properties.put(IUH_PROCESSED_TICKETS_PATH,
                    getPropertyValue(IUH_PROCESSED_TICKETS_PATH, null));
        }
        return properties
    }

    private boolean checkPropertiesValues (File propertiesFile)
    {
        if (PropertiesUtils.checkPropertyEquals(propertiesFile, collectProperties()).isEmpty()) {
            return true;
        }
        return false;
    }

    private void updateRequiredProperty(File propertiesFile)
    {
        log.info("Updating file: " + propertiesFile);
        List<String> fileLines = FileUtils.readLines(propertiesFile);
        log.info("Updating property: " + IN_FOLDER);
        PropertiesUtils.updateProperty(fileLines, IN_FOLDER, getTransformedPath(collectProperties().get(IUH_IN_FOLDER)),
                "Edited by MEDO script at: " + new Date());
        log.info("Updating property: " + IN_FOLDER_PROCESSED);
        PropertiesUtils.updateProperty(fileLines, IN_FOLDER_PROCESSED, getTransformedPath(collectProperties().get(IUH_IN_FOLDER_PROCESSED)),
                "Edited by MEDO script at: " + new Date());
        log.info("Updating property: " + IN_FOLDER_DISCARDED);
        PropertiesUtils.updateProperty(fileLines, IN_FOLDER_DISCARDED, getTransformedPath(collectProperties().get(IUH_IN_FOLDER_DISCARDED)),
                "Edited by MEDO script at: " + new Date());
        log.info("Updating property: " + OUT_FOLDER_EXPORT);
        PropertiesUtils.updateProperty(fileLines, OUT_FOLDER_EXPORT, getTransformedPath(collectProperties().get(IUH_OUT_FOLDER_EXPORT)),
                "Edited by MEDO script at: " + new Date());
        log.info("Updating property: " + TICKETS_PATH);
        PropertiesUtils.updateProperty(fileLines, TICKETS_PATH, getTransformedPath(collectProperties().get(IUH_TICKETS_PATH)),
                "Edited by MEDO script at: " + new Date());
        log.info("Updating property: " + PROCESSED_TICKETS_PATH);
        PropertiesUtils.updateProperty(fileLines, PROCESSED_TICKETS_PATH, getTransformedPath(collectProperties().get(IUH_PROCESSED_TICKETS_PATH)),
                "Edited by MEDO script at: " + new Date());
        FileUtils.storeLines(propertiesFile, fileLines);
        log.info("Updating file: " + propertiesFile + " finished");
    }

    private String getTransformedPath (String path)
    {
        File checkedPath = new File(path);
        if (checkedPath.isAbsolute()){
            return path;
        } else {
            return map.get('br4j.jboss.configuration.path') + File.separator + path;
        }
    }
}
