package ru.datateh.jbr.iuh

interface Phases {
	
	void init()
	
	boolean check()
	
	void install()
	
	void uninstall()
	
	void finalize()

}
