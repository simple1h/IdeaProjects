package ru.datateh.jbr.iuh.msg;

import java.util.Arrays;

public class Message {
	
	private MessageType state = MessageType.UNDEFINED;
	private String text;
	private Throwable exception;
	
	public Message(MessageType state, String text) {
		this.state = state;
		this.text = text;
	}
	
	public Message(MessageType state, Throwable exception) {
		this.state = state;
		this.text = exception.getMessage();
		this.exception = exception;
	}
	
	public Message(String text) {
		this.text = text;
	}
	
	public MessageType getState() {
		return state;
	}
	
	public void setState(MessageType state) {
		this.state = state;
	}
	
	public String getText() {
		return text;
	}
	
	public void setText(String text) {
		this.text = text;
	}

	@Override
	public String toString() {
		return text;
	}
	
	public String getFullString() {
		return "State: " + state.getText()
				+ ", Message: " + text;
	}
	
	public String getDetailedMessage(){
		if (exception == null){
			return this.toString();
		} else {
			return this.getFullString() + '\n' + Arrays.toString(exception.getStackTrace());
		}
	}

}
