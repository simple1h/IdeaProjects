package ru.datateh.jbr.iuh.utils

import ru.datateh.jbr.iuh.GroovyWrapper
import ru.datateh.jbr.iuh.msg.HarnessException
import ru.datateh.jbr.iuh.msg.Message
import ru.datateh.jbr.iuh.msg.MessageType

import java.nio.charset.Charset

public class FileUtils {

    public static enum Permission {
        READ,
        WRITE;
    }

    static String LOG_CONFIG = "log4j.groovy";

    /**
     * Удаляет указанный файл
     * @param fileName имя файла
     * @return возвращает true, если операция была успешна, иначе false
     */
	public static boolean deleteFile(String fileName) {
		File f = new File(fileName);
		if(f.isFile()) {
			return f.delete()
		}
        return false;
	}

    public static boolean changeFilePermission (File file, Permission permission, boolean forOwner)
    {
        checkFileExist(file, true);
        boolean result;
        switch (permission)
        {
            case Permission.READ:
                if (forOwner)
                {
                    result = file.setReadable(true, true);
                }
                else
                {
                    result = file.setReadable(true, false);
                }
                break;
            case Permission.WRITE:
                if (forOwner)
                {
                    result = file.setWritable(true, true);
                }
                else
                {
                    result = file.setWritable(true, false);
                }
                break;
        }
        return result;
    }

    /**
     * копирует исходный файл, если он присутствует, в файл назначения
     * @param sourceFile исходный файл
     * @param destinationFile файл назначения
     */
    public static void copyFile(File sourceFile, File destinationFile)
    {
        InputStream is = null;
        OutputStream os = null;
        checkFileExist(sourceFile, true);
        try {
            is = new FileInputStream(sourceFile);
            os = new FileOutputStream(destinationFile);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = is.read(buffer)) > 0) {
                os.write(buffer, 0, length);
            }
        } finally {
            is.close();
            os.close();
        }
    }

    /**
     * Проверяет существует ли указанный файл
     * @param file файл
     * @param throwException если true, генерирует исключение {@link ru.datateh.jbr.iuh.msg.HarnessException}
     * @return возвращает true, если файл существует и false если файл не существует и throwException = false
     */
    public static boolean checkFileExist (File file, boolean throwException)
    {
        if (!file.isFile() && throwException)
        {
            throw new HarnessException(new Message(MessageType.ERROR, "Can not find file: " + file));
        }
        else if (!file.isFile() && !throwException)
        {
            return false;
        }
        return true;
    }

    /**
     * читает указанный файл в кодироваке UTF-8 и возвращает список строк
     * @param file файл
     * @return список строк файла
     */
    public static List<String> readLines(File file)
    {
        checkFileExist(file, true);
        List<String> result = new ArrayList<String>();
        String line;
        try {
            InputStream fis = new FileInputStream(file);
            InputStreamReader isr = new InputStreamReader(fis, Charset.forName("UTF-8"));
            BufferedReader br = new BufferedReader(isr);
            while ((line = br.readLine()) != null) {
                result.add(line);
            }
        } catch (Exception e) {
            throw new HarnessException(new Message(MessageType.ERROR, e));
        }
        return result;
    }

    /**
     * Сохраняет список строк в кодировке UTF-8 в файл
     * @param file имя файла
     * @param list список строк
     */
    public static void storeLines(File file, List<String> list)
    {
        PrintWriter writer = new PrintWriter(file, "UTF-8");
        for (String line : list)
        {
            writer.println(line);
        }
        writer.close();
    }

    /**
     * Возвращает файл настроек логирования
     * @return файл настроек логирования
     */
    public static File getLogConfigFile ()
    {
        File logConfig = new File(LOG_CONFIG);
        if (checkFileExist(logConfig, false))
        {
            return logConfig;
        }
        logConfig = new File(getCodeSourcePath() + File.separator + LOG_CONFIG);
        if (checkFileExist(logConfig, false))
        {
            return logConfig;
        }
        return null;
    }

    /**
     * Возвращает путь к папке в которой расположен jar-файл оснастки
     * @return путь к папке в которой расположен jar-файл оснастки
     */
    public static String getCodeSourcePath ()
    {
        GroovyWrapper wrapper = new GroovyWrapper();
        File sourcePath = new File (wrapper.getClass().getProtectionDomain().getCodeSource().getLocation().getPath());
        return sourcePath.getParent();
    }

}
