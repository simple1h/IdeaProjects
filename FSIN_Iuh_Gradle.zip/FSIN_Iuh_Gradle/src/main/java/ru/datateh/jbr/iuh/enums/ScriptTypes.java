package ru.datateh.jbr.iuh.enums;

public enum ScriptTypes {
	
	GROOVY("groovy"),
	
	SH("sh");
	
	private String type;
	
	ScriptTypes(String type) {
		this.type = type;
	}
	
	public String getType() {
		return type;
	}
	
	public static ScriptTypes getScriptType(String type) {
		for(ScriptTypes st : ScriptTypes.values()) {
			if(st.getType().equalsIgnoreCase(type)) {
				return st;
			}
		}
		return null;
	}

}
