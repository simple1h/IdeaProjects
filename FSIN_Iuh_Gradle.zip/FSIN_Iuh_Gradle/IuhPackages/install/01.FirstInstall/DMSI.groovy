import groovy.util.logging.Log4j
import ru.datateh.jbr.iuh.AbstractExecute
import ru.datateh.jbr.iuh.utils.FileUtils
import ru.datateh.jbr.iuh.utils.PropertiesUtils

/**
 * @author etarakanov
 * Date: 10.02.15
 * Time: 17:31
 */
@Log4j
public class DMSI extends AbstractExecute
{
    private static String IUH_STANDART = "br4j.dbmi.standart";
    private static String IUH_VERSION = "br4j.dbmi.version";
    private static String IUH_SYS_ID = "br4j.dbmi.sys_id";
    private static String IUH_SYSTEM = "br4j.dbmi.system";
    private static String IUH_SYSTEM_DETAILS = "br4j.dbmi.system_details";
    private static String IUH_DEFAULT_ORGANIZATION_ID = "br4j.dbmi.default_organization_id";

    private static String STANDART = "standart";
    private static String VERSION = "version";
    private static String SYS_ID = "sys_id";
    private static String SYSTEM = "system";
    private static String SYSTEM_DETAILS = "system_details";
    private static String DEFAULT_ORGANIZATION_ID = "default_organization_id";

    private Map<String, String> properties;

    @Override
    void install() {
        log.info "DMSI is running... "

        File fileProperties = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'dmsi' + File.separator + 'config.properties');

        File exampleProperties = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'dmsi' + File.separator + 'config.properties.example');

        if (!FileUtils.checkFileExist(fileProperties, false) && FileUtils.checkFileExist(exampleProperties, true))
        {
            log.info "Property file: " + fileProperties + " missing. File will be created from copy: " + exampleProperties;
            FileUtils.copyFile(exampleProperties, fileProperties);
            if (!checkPropertiesValues(fileProperties)) {
                updateRequiredProperty(fileProperties);
            }
            FileUtils.changeFilePermission(fileProperties, FileUtils.Permission.WRITE, false);
        }
    }

    private Map<String, String> collectProperties ()
    {
        if (properties == null)
        {
            properties = new HashMap<String, String>();
            properties.put(IUH_STANDART, getPropertyValue(IUH_STANDART, null));
            properties.put(IUH_VERSION, getPropertyValue(IUH_VERSION, null));
            properties.put(IUH_SYS_ID, getPropertyValue(IUH_SYS_ID, null));
            properties.put(IUH_SYSTEM, getPropertyValue(IUH_SYSTEM, null));
            properties.put(IUH_SYSTEM_DETAILS, getPropertyValue(IUH_SYSTEM_DETAILS, null));
            properties.put(IUH_DEFAULT_ORGANIZATION_ID, getPropertyValue(IUH_DEFAULT_ORGANIZATION_ID, null));
        }
        return properties
    }

    private boolean checkPropertiesValues (File propertiesFile)
    {
        if (PropertiesUtils.checkPropertyEquals(propertiesFile, collectProperties()).isEmpty()) {
            return true;
        }
        return false;
    }

    private void updateRequiredProperty(File propertiesFile)
    {
        log.info("Updating file: " + propertiesFile);
        List<String> fileLines = FileUtils.readLines(propertiesFile);
        log.info("Updating property: " + STANDART);
        PropertiesUtils.updateProperty(fileLines, STANDART, collectProperties().get(IUH_STANDART),
                "Edited by DMSI script at: " + new Date());
        log.info("Updating property: " + VERSION);
        PropertiesUtils.updateProperty(fileLines, VERSION, collectProperties().get(IUH_VERSION),
                "Edited by DMSI script at: " + new Date());
        log.info("Updating property: " + SYS_ID);
        PropertiesUtils.updateProperty(fileLines, SYS_ID, collectProperties().get(IUH_SYS_ID),
                "Edited by DMSI script at: " + new Date());
        log.info("Updating property: " + SYSTEM);
        PropertiesUtils.updateProperty(fileLines, SYSTEM, collectProperties().get(IUH_SYSTEM),
                "Edited by DMSI script at: " + new Date());
        log.info("Updating property: " + SYSTEM_DETAILS);
        PropertiesUtils.updateProperty(fileLines, SYSTEM_DETAILS, collectProperties().get(IUH_SYSTEM_DETAILS),
                "Edited by DMSI script at: " + new Date());
        log.info("Updating property: " + DEFAULT_ORGANIZATION_ID);
        PropertiesUtils.updateProperty(fileLines, DEFAULT_ORGANIZATION_ID, collectProperties().get(IUH_DEFAULT_ORGANIZATION_ID),
                "Edited by DMSI script at: " + new Date());
        FileUtils.storeLines(propertiesFile, fileLines);
        log.info("Updating file: " + propertiesFile + " finished");
    }

    public static void main(String[] args) {
        new DMSI().start()
    }
}
