package cardLifeCycles.outgoing.scripts

import com.aplana.dbmi.tests.base.system.impl.BaseScriptRunnable

/**
 * @author etarakanov
 * Date: 10.10.14
 * Time: 17:03
 */
/**
 * скрипт регистарации карточки шаблона документа "Исходящий" регистратором
 */
public class RegistrationCard extends BaseScriptRunnable
{
    @Override
    void run()
    {
//        String cardCode = getPropertyFromContext("cardCode")
        String cardCode = "13261634"

        performWithException(
                action('openCard','Открыть карточку с кодом: ' + cardCode, 'Карточка открыта','','outgoingSectionPage','','navigateTo'),
                argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=e&windowstate=normal&mode=view&MI_EDIT_CARD=" + cardCode))

        performWithException(action('clickChangeStatus','Нажать на кнопку изменить статус', 'Кнопка нажата','','buttonPanelPage','changeStatusButton','click'), null)

        performWithException(action('clickSendToARMManager','Нажать на кнопку "Зарегистрировать"', 'Кнопка нажата','','buttonPanelPage','registrationButton','click'), null)

        Thread.sleep(4000)
        performWithException(action('conformSerialNumber','Подтвердить валовый номер', 'Кнопка нажата','','mainCardPage','okButton','click'), null)
        Thread.sleep(3000)

        performUntilSuccess(15, 15000)
                {
                    performWithException(
                            action('openCard','Открыть карточку с кодом: ' + cardCode, 'Карточка открыта','','outgoingSectionPage','','navigateTo'),
                            argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=e&windowstate=normal&mode=view&MI_EDIT_CARD=" + cardCode))

                    performWithException(action('clickCardInfoArrow','Раскрытие вкладки дополнительной информации', 'Вкладка раскрыта','','mainCardPage','infoHeaderButton','click'), null)

                    performWithException(
                            action('checkTemplate','Проверка типа шаблона карточки. Ожидается: Исходящий', 'Проверка выполенена','','mainCardPage','templateLabel','compareText'),
                            argument("text", "empty", "Исходящий"),
                            performWithException(action('getTemplate','Получить типа шаблона карточки документа', 'Тип шаблона получен','','mainCardPage','templateLabel','getText'), null))

                    performWithException(
                            action('checkCardState','Проверка статуса карточки. Ожидается: Зарегистрирован', 'Проверка выполенена','','mainCardPage','cardStateLabel','compareText'),
                            argument("text", "empty", "Зарегистрирован"),
                            performWithException(action('getCardState','Получить статус открытой карточки', 'Статус получен','','mainCardPage','cardStateLabel','getText'), null))
                }

        String registrationNumber = performWithException(action('getRegNumber','Получить регистрационный номер карточки', 'Код получен','','registrationData','registrationNumber','getText'), null).getStringValue()

        storePropertyInContext("registrationNumber":registrationNumber)

        performWithException(
                action('backAction','Переход назад', 'Переход выполнен','','mainCardPage','','navigateTo'),
                argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=9&windowstate=normal&MI_ACTION_FIELD=MI_BACK_ACTION"))
    }
}
