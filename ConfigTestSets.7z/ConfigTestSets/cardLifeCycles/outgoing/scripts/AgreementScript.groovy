package cardLifeCycles.outgoing.scripts
import com.aplana.dbmi.tests.base.system.impl.BaseScriptRunnable
/**
 * @author etarakanov
 * Date: 09.10.14
 * Time: 15:03
 */

/**
 * скрипт согласования карточки исходящего документа (отправить по маршруту)
 */

public class AgreementScript extends BaseScriptRunnable
{
    @Override
    void run()
    {
        String cardCode = getPropertyFromContext("cardCode")
//        String cardCode = "13261255"

        performWithException(
                action('openCard','Открыть карточку с кодом: ' + cardCode, 'Карточка открыта','','outgoingSectionPage','','navigateTo'),
                argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=e&windowstate=normal&mode=view&MI_EDIT_CARD=" + cardCode)
        )

        performWithException(
                action('openAgreementTab','Переход к вкладке согласование', 'Переход выполнен','','mainCardPage','','navigateTo'),
                argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=1&MI_ACTION_FIELD=CHANGE_TAB_CARD_ACTION&TAB_ID=290")
        )

        performWithException(
                action('transferCardToEditMode','Перевод карточки \'Исходящего\' в режим редактирования', 'Переход выполнен','','mainCardPage','','navigateTo'),
                argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=9&windowstate=maximized&MI_ACTION_FIELD=MI_EDIT_CARD_ACTION&TAB_ID=290")
        )

        performWithException(action('clickAddAgreements','Нажатие на кнопку \'Добавить согласующих\'', 'Кнопка нажата','','mainCardPage','addAgreements','click'),null)

        performWithException(
                action('addAgreement','Добавить согласующего', 'Согласующий добавлен','','mainCardPage','agreementFIO','selectText'),
                argument("fio", "empty", "Рудый Анатолий Анатольевич")
        )

        performWithException(
                action('addAgreementOrder','Добавить порядок согласования', 'Порядок согласования добавлен','','mainCardPage','agreementOrder','setText'),
                argument("order", "empty", "1")
        )

        performWithException(action('clickDoneButton','Нажать кнопку \'Готово\'', 'Кнопка нажата','','buttonPanelPage','doneButton','click'),null)
        performWithException(action('clickCloseButton','Нажать кнопку \'Закрыть\'', 'Кнопка нажата','','buttonPanelPage','closeButton','click'),null)
        performWithException(action('acceptEditCard','Подтвердить изменения карточки', 'Изменения подтверждены','','mainCardPage','acceptEditButton','click'),null)

        performWithException(
                action('backAction','Переход назад', 'Переход выполнен','','mainCardPage','','navigateTo'),
                argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=9&windowstate=normal&MI_ACTION_FIELD=MI_BACK_ACTION")
        )


        performWithException(
                action('openCard','Открыть карточку с кодом: ' + cardCode, 'Карточка открыта','','outgoingSectionPage','','navigateTo'),
                argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=e&windowstate=normal&mode=view&MI_EDIT_CARD=" + cardCode)
        )
        performUntilSuccess(15, 15000)
                {
                    performWithException(
                            action('openAgreementTab','Переход к вкладке согласование', 'Переход выполнен','','mainCardPage','','navigateTo'),
                            argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=1&MI_ACTION_FIELD=CHANGE_TAB_CARD_ACTION&TAB_ID=290")
                    )

                    performWithException(
                            action('clickAgreementFI','Открытие карточки \'Визирования\'. Согласующий: Рудый Анатолий', 'Карточка открыта','','mainCardPage','visa','clickCellColumnElement'),
                            argument("FI", "empty", "Рудый Анатолий")
                    )

                    performWithException(action('clickCardInfoArrow','Раскрытие вкладки дополнительной информации', 'Вкладка раскрыта','','mainCardPage','infoHeaderButton','click'), null)

                    String visaCardCode = performWithException(action('getCardCode','Получение кода карточки визирования', 'Код карточки получен','','mainCardPage','cardCodeLabel','getText'), null).getStringValue()

                    storePropertyInContext("visaCardCode":visaCardCode)

                    def template = performWithException(action('getTemplate','Получить типа шаблона карточки документа', 'Тип шаблона получен','','mainCardPage','templateLabel','getText'), null)
                    performWithException(
                            action('checkTemplate','Проверка типа шаблона карточки. Ожидается: Визирование', 'Проверка выполенена','','mainCardPage','templateLabel','compareText'),
                            argument("text", "empty", "Визирование"),template)

                    def cardState = performWithException(action('getCardState','Получить статус открытой карточки', 'Статус получен','','mainCardPage','cardStateLabel','getText'), null)
                    performWithException(
                            action('checkCardState','Проверка статуса карточки. Ожидается: Черновик', 'Проверка выполенена','','mainCardPage','cardStateLabel','compareText'),
                            argument("text", "empty", "Черновик"),cardState)
                }

        performWithException(
                action('backAction','Переход назад', 'Переход выполнен','','mainCardPage','','navigateTo'),
                argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=9&windowstate=normal&MI_ACTION_FIELD=MI_BACK_ACTION")
        )


        performUntilSuccess(15, 15000)
                {
                    performWithException(
                            action('openCard','Открыть карточку с кодом: ' + cardCode, 'Карточка открыта','','outgoingSectionPage','','navigateTo'),
                            argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=e&windowstate=normal&mode=view&MI_EDIT_CARD=" + cardCode)
                    )
                    performWithException(action('clickChangeStatus','Нажать на кнопку изменить статус', 'Кнопка нажата','','buttonPanelPage','changeStatusButton','click'), null)
                }

        performWithException(action('clickSendToRoute','Нажать на кнопку "Отправить по маршруту"', 'Кнопка нажата','','buttonPanelPage','sendToRouteMenu','click'), null)

        performWithError
                {
                    performWithException(action('cancelEcp','Отменить ЭЦП', 'Кнопка нажата','','mainCardPage','cancelEcp','click'), null)
                }

        performWithException(
                action('openCard','Открыть карточку с кодом: ' + cardCode, 'Карточка открыта','','outgoingSectionPage','','navigateTo'),
                argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=e&windowstate=normal&mode=view&MI_EDIT_CARD=" + cardCode)
        )
        performUntilSuccess(15, 15000)
                {
                    performWithException(
                            action('openAgreementTab','Переход к вкладке согласование', 'Переход выполнен','','mainCardPage','','navigateTo'),
                            argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=1&MI_ACTION_FIELD=CHANGE_TAB_CARD_ACTION&TAB_ID=290")
                    )

                    performWithException(action('clickCardInfoArrow','Раскрытие вкладки дополнительной информации', 'Вкладка раскрыта','','mainCardPage','infoHeaderButton','click'), null)

                    def template = performWithException(action('getTemplate','Получить типа шаблона карточки документа', 'Тип шаблона получен','','mainCardPage','templateLabel','getText'), null)
                    performWithException(
                            action('checkTemplate','Проверка типа шаблона карточки. Ожидается: Исходящий', 'Проверка выполенена','','mainCardPage','templateLabel','compareText'),
                            argument("text", "empty", "Исходящий"),template)

                    def cardState = performWithException(action('getCardState','Получить статус открытой карточки', 'Статус получен','','mainCardPage','cardStateLabel','getText'), null)
                    performWithException(
                            action('checkCardState','Проверка статуса карточки. Ожидается: Согласование', 'Проверка выполенена','','mainCardPage','cardStateLabel','compareText'),
                            argument("text", "empty", "Согласование"),cardState)
                }

        performWithException(
                action('backAction','Переход назад', 'Переход выполнен','','mainCardPage','','navigateTo'),
                argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=9&windowstate=normal&MI_ACTION_FIELD=MI_BACK_ACTION")
        )
    }
}
