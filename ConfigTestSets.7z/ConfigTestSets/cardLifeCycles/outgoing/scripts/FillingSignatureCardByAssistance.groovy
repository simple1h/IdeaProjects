package cardLifeCycles.outgoing.scripts
import com.aplana.dbmi.tests.base.system.impl.BaseScriptRunnable
/**
 * @author etarakanov
 * Date: 10.10.14
 * Time: 15:01
 */
/**
 * скрипт заполнения карточки подписи и направление ее АРМ руководителя помощником подписанта
 */
public class FillingSignatureCardByAssistance extends BaseScriptRunnable
{
    @Override
    void run()
    {
        String cardCode = getPropertyFromContext("cardCode")
//        String cardCode = "13261424"

        performWithException(
                action('openCard','Открыть карточку с кодом: ' + cardCode, 'Карточка открыта','','outgoingSectionPage','','navigateTo'),
                argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=e&windowstate=normal&mode=view&MI_EDIT_CARD=" + cardCode))

        performWithException(
                action('openSigningTab','Переход к вкладке подписание', 'Переход выполнен','','outgoingSectionPage','','navigateTo'),
                argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=1&MI_ACTION_FIELD=CHANGE_TAB_CARD_ACTION&TAB_ID=285"))

        performWithException(action('openSignatoryCard','Открытие карточки подписания', 'Карточка открыта','','signingSection','signatoryFI','click'), null)

        performWithException(action('clickCardInfoArrow','Раскрытие вкладки дополнительной информации', 'Вкладка раскрыта','','signingSection','infoHeaderButton','click'), null)

        String signatoryCardCode = performWithException(action('getCardCode','Получение кода карточки подписания', 'Код карточки получен','','signingSection','cardCodeLabel','getText'), null).getStringValue()

        storePropertyInContext("signatoryCardCode":signatoryCardCode)

        performWithException(
                action('checkTemplate','Проверка типа шаблона карточки. Ожидается: Подпись', 'Проверка выполенена','','signingSection','templateLabel','compareText'),
                argument("text", "empty", "Подпись"),
                performWithException(action('getTemplate','Получить типа шаблона карточки документа', 'Тип шаблона получен','','signingSection','templateLabel','getText'), null))

        performWithException(
                action('checkCardState','Проверка статуса карточки. Ожидается: Обработка помощником', 'Проверка выполенена','','signingSection','cardStateLabel','compareText'),
                argument("text", "empty", "Обработка помощником"),
                performWithException(action('getCardState','Получить статус открытой карточки', 'Статус получен','','signingSection','cardStateLabel','getText'), null))

        performWithException(
                action('transferToEditMode','Перевести карточку подписи в режим редактирования', 'Переход выполнен','','signingSection','','navigateTo'),
                argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=9&windowstate=maximized&MI_ACTION_FIELD=MI_EDIT_CARD_ACTION&TAB_ID=202"))

        performWithException(
                action('setCurrentResolution','Установить текущее решение', 'Текущее решение установлено','','signingSection','currentResolution','setText'),
                argument("text", "empty", "Решение помощника подписанта"))

        performWithException(action('clickChangeStatus','Нажать на кнопку изменить статус', 'Кнопка нажата','','buttonPanelPage','changeStatusButton','click'), null)

        performWithException(action('clickSendToARMManager','Нажать на кнопку "В арм руководителя"', 'Кнопка нажата','','buttonPanelPage','sendToARMManager','click'), null)

        performUntilSuccess(15, 15000)
                {
                    performWithException(
                            action('openCard','Открыть карточку подписания с кодом: ' + signatoryCardCode, 'Карточка открыта','','outgoingSectionPage','','navigateTo'),
                            argument("url", "empty", getSeleniumService().getBaseUrl() + "/portal/auth/portal/dbmi/card/CardPortletWindow?action=e&windowstate=normal&mode=view&MI_EDIT_CARD=" + signatoryCardCode))

                    performWithException(action('clickCardInfoArrow','Раскрытие вкладки дополнительной информации', 'Вкладка раскрыта','','signingSection','infoHeaderButton','click'), null)

                    performWithException(
                            action('checkTemplate','Проверка типа шаблона карточки. Ожидается: Подпись', 'Проверка выполенена','','signingSection','templateLabel','compareText'),
                            argument("text", "empty", "Подпись"),
                            performWithException(action('getTemplate','Получить типа шаблона карточки документа', 'Тип шаблона получен','','signingSection','templateLabel','getText'), null))

                    performWithException(
                            action('checkCardState','Проверка статуса карточки. Ожидается: Подписание', 'Проверка выполенена','','signingSection','cardStateLabel','compareText'),
                            argument("text", "empty", "Подписание"),
                            performWithException(action('getCardState','Получить статус открытой карточки', 'Статус получен','','signingSection','cardStateLabel','getText'), null))
                }
    }
}

