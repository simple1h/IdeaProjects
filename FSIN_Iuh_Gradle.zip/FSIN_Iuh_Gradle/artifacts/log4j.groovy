log4j {

appender.stdout = "org.apache.log4j.ConsoleAppender"
appender."stdout.layout"="org.apache.log4j.PatternLayout"
appender."stdout.Threshold"="INFO"

appender.scrlog="org.apache.log4j.RollingFileAppender"
appender."scrlog.layout"="org.apache.log4j.PatternLayout"
appender."scrlog.Threshold"="all"
appender."scrlog.layout.ConversionPattern"="%d %-5r %-5p [%c] %m%n"
appender."scrlog.file"="iuh.log"
appender."scrlog.append"="true"
appender."scrlog.MaxFileSize"="10MB"
appender."scrlog.MaxBackupIndex"="10"

rootLogger="all,stdout,scrlog"
}