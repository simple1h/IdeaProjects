import groovy.util.logging.Log4j
import ru.datateh.jbr.iuh.AbstractExecute
import ru.datateh.jbr.iuh.utils.FileUtils

/**
 * @author etarakanov
 * Date: 27.03.2015
 * Time: 12:46
 */

@Log4j
public class Stamp extends AbstractExecute
{
    public void install()
    {
        log.info "Stamp is running... "
        File exampleProperties = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'card' + File.separator + 'stamp' + File.separator + 'stamp.properties.example');
        File fileProperties = new File(map.get('br4j.jboss.configuration.path')
                + File.separator + 'conf' + File.separator + 'dbmi' + File.separator + 'card' + File.separator + 'stamp' + File.separator +  + 'stamp.properties');
        log.info "File: " + fileProperties + " will be created from copy: " + exampleProperties;
        FileUtils.copyFile(exampleProperties, fileProperties);
        FileUtils.changeFilePermission(fileProperties, FileUtils.Permission.WRITE, false);
    }

    public static void main(String[] args) {
        new Stamp().start()
    }
}
